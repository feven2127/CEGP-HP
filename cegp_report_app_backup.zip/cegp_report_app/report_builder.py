"""
report_builder.py

Turns a list of DetectionRecord objects into the summary numbers and
tables the executive report template needs, using the category-based
expected-value cost model in cost_reference.py (no manual cost input).
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass

from vision_one_client import DetectionRecord
from cost_reference import categorize, CATEGORY_MODEL


@dataclass
class CategoryLine:
    category: str
    count: int
    unit_value: float
    subtotal: float
    cost_source: str
    credit_source: str
    prevention_credit: float
    cost_if_successful: float
    scan_share: float | None = None


@dataclass
class ReportData:
    customer_name: str
    period_start: str
    period_end: str
    total_blocked: int
    total_saved: float
    category_lines: list[CategoryLine]
    threats_by_type: list[tuple[str, int]]
    top_targeted_recipients: list[tuple[str, int]]
    daily_counts: list[tuple[str, int]]
    sample_detections: list[dict]
    total_scanned: int | None
    block_rate: float | None
    restore_count: int | None
    false_positive_rate: float | None
    efficacy_available: bool
    # rev 2: detections are not all blocks -- keep them separate so the
    # headline "blocked" figure is defensible.
    total_detections: int = 0
    detected_not_blocked: int = 0
    unique_messages_blocked: int = 0
    simulation_excluded: int = 0
    unmapped_actions: list[str] = None
    # Mail tracking: full mail-flow status breakdown, not just the blocked
    # side. total_tracked/mail_status_breakdown are None/empty when neither
    # side of accepted-mail data was available.
    delivered_flagged_count: int | None = None
    delivered_clean_count: int | None = None
    total_tracked: int = 0
    mail_status_breakdown: list[tuple[str, int, float | None]] = None


def build_report_data(
    records: list[DetectionRecord],
    customer_name: str,
    period_start: str,
    period_end: str,
    total_scanned: int | None = None,
    restore_count: int | None = None,
    delivered_flagged_count: int | None = None,
) -> ReportData:
    # rev 2: split on the `act` field instead of assuming every detection
    # was a block. Simulation-mode records are excluded from both sides --
    # they represent what *would* have happened, not what did.
    total_detections = len(records)
    simulation_excluded = sum(1 for r in records if r.is_simulation)
    live = [r for r in records if not r.is_simulation]

    blocked = [r for r in live if r.was_blocked]
    not_blocked = [r for r in live if not r.was_blocked]

    total_blocked = len(blocked)
    detected_not_blocked = len(not_blocked)

    # One message can trigger several filters, so detection count > message
    # count. Report both: the ledger is per-detection, the customer-facing
    # "messages stopped" figure should be per-message.
    unique_messages_blocked = len({r.msg_uuid for r in blocked if r.msg_uuid})

    # Any act value we don't recognize is counted as NOT blocked (see
    # was_blocked). Surface them so the maps can be corrected rather than
    # quietly under-reporting.
    unmapped_actions = sorted({r.action for r in live if r.action_is_unmapped})

    category_counter: Counter = Counter()
    for r in blocked:
        category_counter[categorize(r.threat_name)] += 1

    category_lines: list[CategoryLine] = []
    total_saved = 0.0
    for category, count in category_counter.most_common():
        model = CATEGORY_MODEL.get(category, CATEGORY_MODEL["Other"])
        unit_value = model["cost_if_successful"] * model["prevention_credit"]
        subtotal = unit_value * count
        total_saved += subtotal
        category_lines.append(
            CategoryLine(
                category=category,
                count=count,
                unit_value=unit_value,
                subtotal=subtotal,
                cost_source=model["cost_source"],
                credit_source=model["credit_source"],
                prevention_credit=model["prevention_credit"],
                cost_if_successful=model["cost_if_successful"],
            )
        )

    threat_counter = Counter(r.threat_name for r in blocked)
    threats_by_type = threat_counter.most_common(10)

    recipient_counter = Counter(r.recipient for r in blocked if r.recipient)
    top_recipients = recipient_counter.most_common(5)

    day_counter: Counter = Counter()
    for r in blocked:
        day = (r.detected_time or "")[:10]
        if day:
            day_counter[day] += 1
    daily_counts = sorted(day_counter.items())

    sample = [
        {
            "time": r.detected_time,
            "threat": r.threat_name,
            "sender": r.sender,
            "recipient": r.recipient,
            "subject": r.subject,
            "action": r.action or "(none)",
        }
        for r in blocked[:25]
    ]

    block_rate = None
    if total_scanned:  # None or 0 both mean "can't compute a rate"
        block_rate = (total_blocked / total_scanned) * 100

    false_positive_rate = None
    if restore_count is not None and total_blocked:
        false_positive_rate = (restore_count / total_blocked) * 100

    # "Available" means we have a usable (non-zero) denominator to compute
    # rates from -- total_scanned == 0 is technically "not None" but can't
    # produce a meaningful block rate, so it's treated the same as missing.
    efficacy_available = bool(total_scanned)

    # Attach each category's share of total *scanned* volume (not just of
    # blocked mix) -- a distinct "catch rate" view from the dollar ledger.
    for line in category_lines:
        line.scan_share = (
            (line.count / total_scanned) * 100 if total_scanned else None
        )

    # Mail tracking: volume by action/status across the WHOLE mail flow,
    # not just blocked messages. Built from whichever pieces are actually
    # available -- degrades one bucket at a time rather than all-or-nothing.
    delivered_clean_count = None
    if total_scanned is not None and delivered_flagged_count is not None:
        delivered_clean_count = max(total_scanned - delivered_flagged_count, 0)

    total_tracked = total_detections + (total_scanned or 0)

    mail_status_breakdown: list[tuple[str, int, float | None]] = []

    def _bucket(label: str, n: int):
        pct = (n / total_tracked * 100) if total_tracked else None
        mail_status_breakdown.append((label, n, pct))

    _bucket("Blocked / quarantined", total_blocked)
    if detected_not_blocked:
        _bucket("Detected, not blocked (monitor mode)", detected_not_blocked)
    if delivered_flagged_count is not None:
        _bucket("Delivered – flagged (spam/graymail)", delivered_flagged_count)
        if delivered_clean_count is not None:
            _bucket("Delivered – clean", delivered_clean_count)
    elif total_scanned is not None:
        _bucket("Delivered", total_scanned)

    return ReportData(
        customer_name=customer_name,
        period_start=period_start,
        period_end=period_end,
        total_blocked=total_blocked,
        total_saved=total_saved,
        category_lines=category_lines,
        threats_by_type=threats_by_type,
        top_targeted_recipients=top_recipients,
        daily_counts=daily_counts,
        sample_detections=sample,
        total_scanned=total_scanned,
        block_rate=block_rate,
        restore_count=restore_count,
        false_positive_rate=false_positive_rate,
        efficacy_available=efficacy_available,
        total_detections=total_detections,
        detected_not_blocked=detected_not_blocked,
        unique_messages_blocked=unique_messages_blocked,
        simulation_excluded=simulation_excluded,
        unmapped_actions=unmapped_actions,
        delivered_flagged_count=delivered_flagged_count,
        delivered_clean_count=delivered_clean_count,
        total_tracked=total_tracked,
        mail_status_breakdown=mail_status_breakdown,
    )
