"""
cost_reference.py

There is no single official Trend Micro "cost per incident" table (confirmed
internally) — Trend Micro's own value-quantification tool (Cyber Risk
Quantification / CREM) generates figures dynamically per customer rather than
publishing a static table, and internal sales materials otherwise lean on
external analyst data (IBM, FBI IC3, Verizon DBIR, Arctic Wolf, ESG).

This module builds a small, transparent EXPECTED-VALUE model instead of
applying one flat "cost per incident" to every blocked message. Applying a
full breach-scale cost (e.g. $4.88M) to every single blocked phishing email
would wildly overstate savings, since most blocked messages would never have
succeeded even if delivered.

For each category:
  cost_if_successful   -> a real, cited industry figure for what a
                           SUCCESSFUL attack of this type costs on average
  prevention_credit     -> a conservative, clearly-labeled ASSUMPTION for
                           the share of blocked messages that would plausibly
                           have succeeded if not blocked (informed by, not
                           equated to, published click/compromise rates)
  expected_value        -> cost_if_successful * prevention_credit
                           (the amount credited per blocked message)

Both numbers are shown in the report so the customer can see the reasoning,
not just a final number. Adjust CATEGORY_MODEL below if your team has a
different agreed methodology (e.g. output from Vision One CRQ for a specific
customer).
"""

from __future__ import annotations

CATEGORY_MODEL = {
    "Spam or Phish": {
        "cost_if_successful": 4_880_000,
        "cost_source": "IBM Cost of a Data Breach Report 2025 — avg. cost of a phishing-initiated breach",
        "prevention_credit": 0.005,
        "credit_source": "Conservative assumption — this is CEGP's blended catch-all filter action, mixing confirmed phishing with large volumes of ordinary spam, so a much smaller share is genuinely dangerous than a named-phishing detection",
    },
    "Phishing": {
        "cost_if_successful": 4_880_000,
        "cost_source": "IBM Cost of a Data Breach Report 2025 — avg. cost of a phishing-initiated breach",
        "prevention_credit": 0.03,
        "credit_source": "Conservative assumption informed by Verizon DBIR 2025 avg. phishing click rate (~2.7%)",
    },
    "Email Authentication Failure": {
        "cost_if_successful": 123_000,
        "cost_source": "FBI IC3 2025 Internet Crime Report — avg. reported BEC loss per case (spoofed/forged senders are a common BEC precursor)",
        "prevention_credit": 0.02,
        "credit_source": "Conservative assumption — most DMARC/SPF/DKIM failures are misconfigured legitimate senders, not active spoofing attempts",
    },
    "Business Email Compromise": {
        "cost_if_successful": 123_000,
        "cost_source": "FBI IC3 2025 Internet Crime Report — avg. reported BEC loss per case",
        "prevention_credit": 0.10,
        "credit_source": "Conservative assumption — not all delivered BEC lures would bypass other financial controls",
    },
    "Ransomware": {
        "cost_if_successful": 1_850_000,
        "cost_source": "Industry ransomware research (2026) — avg. total incident impact",
        "prevention_credit": 0.05,
        "credit_source": "Conservative assumption — successful encryption typically requires user action beyond email delivery",
    },
    "Malware": {
        "cost_if_successful": 250_000,
        "cost_source": "Estimate — typical incident response & remediation cost for a generic malware infection",
        "prevention_credit": 0.05,
        "credit_source": "Conservative assumption, same rationale as ransomware",
    },
    "Malicious URL": {
        "cost_if_successful": 4_880_000,
        "cost_source": "IBM Cost of a Data Breach Report 2025 — avg. cost of a phishing-initiated breach (URL-based lures treated as phishing)",
        "prevention_credit": 0.03,
        "credit_source": "Conservative assumption informed by Verizon DBIR 2025 avg. phishing click rate (~2.7%)",
    },
    "Spam": {
        "cost_if_successful": 1.50,
        "cost_source": "Estimate — ~2 min of employee time at a loaded hourly cost, not an attack-prevention value",
        "prevention_credit": 1.0,
        "credit_source": "Direct productivity cost, not probabilistic",
    },
    "Other": {
        "cost_if_successful": 50_000,
        "cost_source": "Estimate — generic unclassified detection, conservative placeholder",
        "prevention_credit": 0.05,
        "credit_source": "Conservative assumption pending manual classification",
    },
}

# Keyword -> category, checked IN ORDER (case-insensitive substring match).
# Real CEGP/TMES policy-trigger names are checked first and are more
# specific than the generic fallbacks below them -- order matters here,
# e.g. "spam or phish" must be checked before the bare "spam" fallback.
_CATEGORY_KEYWORDS = [
    ("spam or phish", "Spam or Phish"),
    ("dmarc", "Email Authentication Failure"),
    ("spf rule", "Email Authentication Failure"),
    ("dkim rule", "Email Authentication Failure"),
    ("correlated intelligence", "Other"),
    ("password protected", "Malware"),
    ("recipient size", "Spam"),
    ("graymail", "Spam"),
    ("ransomware", "Ransomware"),
    ("business email compromise", "Business Email Compromise"),
    ("bec", "Business Email Compromise"),
    ("phishing", "Phishing"),
    ("credential", "Phishing"),
    ("brand impersonation", "Phishing"),
    ("malicious url", "Malicious URL"),
    ("url", "Malicious URL"),
    ("spam", "Spam"),
    ("trojan", "Malware"),
    ("malware", "Malware"),
    ("virus", "Malware"),
    ("worm", "Malware"),
]


def categorize(threat_name: str) -> str:
    """Map a raw threat/malware name string to one of CATEGORY_MODEL's keys."""
    name = (threat_name or "").lower()
    for keyword, category in _CATEGORY_KEYWORDS:
        if keyword in name:
            return category
    return "Other"


def expected_value(category: str) -> float:
    model = CATEGORY_MODEL.get(category, CATEGORY_MODEL["Other"])
    return model["cost_if_successful"] * model["prevention_credit"]
